package com.zoro.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.zoro.dao.RegistrationDAO;
import com.zoro.dbutil.DBConnection;
import com.zoro.dbutil.IdGen;
import com.zoro.dto.RegistrationBean;
import com.zoro.utility.RegisteredId;

public class RegistrationDAOImpl implements RegistrationDAO {
	
	
	private   Connection con=null;
	private int noOfRecords=0;

	public String registration(RegistrationBean reg) {
		// TODO Auto-generated method stub
		
		
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		String message="";
		try{
			String id=new IdGen().getId("REGESTERED_ID");
			
			String trId=new RegisteredId().registeredId(id);
			
			String query="insert into registration values(?,?,?,?,?,?,?,?,CURDATE(),?)";
			String query1="insert into login values(?,?,?,?,?)";
			
			
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
		    pst1=con.prepareStatement(query1,pst.RETURN_GENERATED_KEYS);
		    
		    pst.setInt(1, reg.getREG_ID());
		    pst.setString(2, reg.getCANDIDATE_NAME());
		    pst.setString(3, reg.getADDRESS());
		    pst.setString(4, reg.getEMAIL_ID());
		    pst.setString(5, reg.getPASSWORD());
		    pst.setString(6, reg.getCONTACT_NO());
		    pst.setString(7, reg.getUSER_TYPE());
		    pst.setString(8, "INACTIVE");
		    pst.setString(9, trId);
		    int i= pst.executeUpdate();
		    
		    pst1.setInt(1, reg.getREG_ID());
		    pst1.setString(2, reg.getEMAIL_ID());
		    pst1.setString(3, reg.getPASSWORD());
		    pst1.setString(4, "INACTIVE");
		    pst1.setString(5, reg.getUSER_TYPE());
		    int j=pst1.executeUpdate();
		   
		   
		   
		   
		    if(i>0 && j>0){
		    	message="You Are Registered Successfully With zorocabs....";
		    }else{
		   
		    }
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return message;
		
		
	}


	public String regCheck(String email) {
		// TODO Auto-generated method stub
		
		  String status=null;
		  try {
		   String query = "select status from registration where EMAIL_ID='"+email+"'";
		   con=DBConnection.getConnection();
		   PreparedStatement preparedStatement = con.prepareStatement(query);
		   ResultSet rs = preparedStatement.executeQuery();
		   while(rs.next()){
			   
			   status = rs.getString("STATUS");
		   }
		   
		   preparedStatement.close();
		  } catch (SQLException e) {
		   e.printStackTrace();
		  }
		  return status;
		
	}


	public String mailVerified(String email) {
		Statement st=null;
		Statement st1=null;
		String message="";
		int i=0;
		int j=0;
		try{
			
			String query="update registration set STATUS='ACTIVE' where  EMAIL_ID='"+email+"'";
			String query1="update login set STATUS='ACTIVE' where  EMAIL_ID='"+email+"'";
			
			con=DBConnection.getConnection();
			st=con.createStatement();
			st1=con.createStatement();
			
				i=st.executeUpdate(query);
				j=st.executeUpdate(query1);
				if(i>0 && j>0){
					
					message="verified successfully please login here";
				}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return message;
	}


	public RegistrationBean getRegisteredDetails(String email) {
		// TODO Auto-generated method stub
		  RegistrationBean bean=new RegistrationBean();
		  String status=null;
		  try {
		   String query = "select * from registration where EMAIL_ID='"+email+"'";
		   con=DBConnection.getConnection();
		   PreparedStatement preparedStatement = con.prepareStatement(query);
		   ResultSet rs = preparedStatement.executeQuery();
		   
		   while(rs.next()){
			   
			   bean.setREG_ID(rs.getInt("REG_ID"));
			   bean.setCANDIDATE_NAME(rs.getString("CANDIDATE_NAME"));
			   bean.setADDRESS(rs.getString("ADDRESS"));
			   bean.setEMAIL_ID(rs.getString("EMAIL_ID"));
			   bean.setCONTACT_NO(rs.getString("CONTACT_NO"));
			   bean.setREG_DATE(rs.getString("REG_DATE"));
			   bean.setCANDIDATE_ID(rs.getString("CANDIDATE_ID"));
		   }
		   
		   preparedStatement.close();
		  } catch (SQLException e) {
		   e.printStackTrace();
		  }
		  return bean;
	}


	public RegistrationBean viewProfile(String email) {
		// TODO Auto-generated method stub
		  RegistrationBean bean=new RegistrationBean();
		  String status=null;
		  try {
		   String query = "SELECT registration.*,update_reg_user.* from registration left join update_reg_user on registration.EMAIL_ID=update_reg_user.USER_EMAIL where EMAIL_ID='"+email+"'";
		   con=DBConnection.getConnection();
		   PreparedStatement preparedStatement = con.prepareStatement(query);
		   ResultSet rs = preparedStatement.executeQuery();
		   
		   while(rs.next()){
			   
			   	bean.setREG_ID(rs.getInt("REG_ID"));
				bean.setCANDIDATE_NAME(rs.getString("CANDIDATE_NAME"));
				bean.setADDRESS(rs.getString("ADDRESS"));
				bean.setEMAIL_ID(rs.getString("EMAIL_ID"));
				bean.setPASSWORD(rs.getString("PASSWORD"));
				bean.setCONTACT_NO(rs.getString("CONTACT_NO"));
				bean.setUSER_TYPE(rs.getString("USER_TYPE"));
				bean.setREG_DATE(rs.getString("REG_DATE"));
				bean.setSTATUS(rs.getString("STATUS"));
				bean.setCANDIDATE_ID(rs.getString("CANDIDATE_ID"));
				bean.setBUSINESS_NAME(rs.getString("BUSINESS_NAME"));
		   }
		   rs.close();
		   preparedStatement.close();
		  } catch (SQLException e) {
		   e.printStackTrace();
		  }
		  return bean;
	}


	public String insertExtDetailsOfRegUser(RegistrationBean reg) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		String message="";
		int i=0;
		try{
			String sql="select USER_EMAIL from update_reg_user where USER_EMAIL='"+reg.getEMAIL_ID()+"'";
			String query="insert into update_reg_user values(?,?,?)";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			if(!rs.next()){
				
		    pst1=con.prepareStatement(query);
		    pst1.setInt(1, 0);
		    pst1.setString(2, reg.getBUSINESS_NAME());
		    pst1.setString(3, reg.getEMAIL_ID());
		  
		    i= pst1.executeUpdate();
			}
		   
		    if(i>0){
		    	message="yes";
		    }
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return message;
	}
	}
	


