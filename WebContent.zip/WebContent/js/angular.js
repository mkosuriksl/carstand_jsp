  angular.module('myApp', ['ngAnimate', 'ui.bootstrap']);
        angular.module('myApp').controller('myCntrl', function ($scope) {
            $scope.today = function () {
               /* $scope.dt = new Date();*/
            };
            $scope.mindate = new Date();
            $scope.dateformat="dd-MM-yyyy";
            $scope.today();
            $scope.showcalendar = function ($event) {
                $scope.showdp = true;
            };
            $scope.showdp = false;
        });
        
     
        
        
     
        
        
       
        
        