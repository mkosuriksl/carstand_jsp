package com.zoro.daoImpl;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.owtelse.codec.Base64;
import com.zoro.dao.AdminDAO;
import com.zoro.dbutil.DBConnection;
import com.zoro.dto.AddCab;
import com.zoro.dto.AssignDriverCab;
import com.zoro.dto.CabBook;
import com.zoro.dto.CabRoute;
import com.zoro.dto.RegistrationBean;
import com.zoro.dto.TravelerBooking;
import com.zoro.dto.Travellers;
import com.zoro.dto.VehicleType;
import com.zoro.utility.SQLDate;

public class AdminDAOImpl implements AdminDAO {
	
	private   Connection con=null;
	private int noOfRecords=0;

	public List<RegistrationBean> getRegisteredDetails(String userType,String userId) {
		// TODO Auto-generated method stub
		List<RegistrationBean> regList=new ArrayList<RegistrationBean>();
		
		PreparedStatement pst=null;
		String query=null;
		if(userId!=null && !userId.equals("null")){
			query="select * from registration where USER_TYPE='"+userType+"' and EMAIL_ID='"+userId+"'";
		}else{
			query="select * from registration where USER_TYPE='"+userType+"'";
		}

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					RegistrationBean reg=new RegistrationBean();
					
					reg.setREG_ID(rs.getInt("REG_ID"));
					reg.setCANDIDATE_NAME(rs.getString("CANDIDATE_NAME"));
					reg.setADDRESS(rs.getString("ADDRESS"));
					reg.setEMAIL_ID(rs.getString("EMAIL_ID"));
					reg.setCONTACT_NO(rs.getString("CONTACT_NO"));
					reg.setUSER_TYPE(rs.getString("USER_TYPE"));
					reg.setSTATUS(rs.getString("STATUS"));
					reg.setREG_DATE(new SQLDate().getInDate(rs.getString("REG_DATE")));
					reg.setCANDIDATE_ID(rs.getString("CANDIDATE_ID"));
					regList.add(reg);
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return regList;
	}

	public Set<String> getUserId(String userType) {
		// TODO Auto-generated method stub
		Set<String> userTypeSet=new TreeSet<String>();
		
		PreparedStatement pst=null;

			try {
				String query="select EMAIL_ID from registration where USER_TYPE='"+userType+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
				userTypeSet.add(rs.getString("EMAIL_ID"));
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return userTypeSet;
	}

	public String changeStatus(String status, String email) {
		// TODO Auto-generated method stub
		String msg=null;
		PreparedStatement pst=null;
		PreparedStatement pst1=null;

			try {
				String query="update registration set STATUS='"+status+"' where  EMAIL_ID='"+email+"'";
				String query1="update login set STATUS='"+status+"' where  EMAIL_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			    pst1=con.prepareStatement(query1);
			    
			    int i=pst.executeUpdate();
			    int j=pst1.executeUpdate();
			
			if(i>0 && j>0){
				if(status!=null && status.equals("ACTIVE")){
				msg=email+" Activated Successfully!.";	
				}else if(status!=null && status.equals("INACTIVE")){
					msg=email+" Inactivated Successfully!.";
				}else if(status!=null && status.equals("BLOCK")){
					msg=email+" Blocked Successfully!.";
				}
			}else{
				msg="SomeThing Went Wrong Please Try Once Again!.";
			}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return msg;
	}

	public String addVehicleType(String brand,String model, String email,String noOfPas, InputStream image) {
		// TODO Auto-generated method stub
		String msg=null;
		PreparedStatement pst=null;

			try {
				String query="insert into vehicle_type values(?,?,?,?,?,?)";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			    
			    pst.setInt(1, 0);
			    pst.setString(2, brand);
			    pst.setBlob(3, image);
			    pst.setString(4, email);
			    pst.setString(5, noOfPas);
			    pst.setString(6, model);
			    int i=pst.executeUpdate();
				
			    if(i>0){
			    	msg="vehicle type added successfully!.";
			    }
			    
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return msg;
	}

	public List<VehicleType> searchVehicleType(String email) {
		// TODO Auto-generated method stub
		List<VehicleType> vehicleList=new ArrayList<VehicleType>();
		
		PreparedStatement pst=null;

		
			try {
				String query="select * from vehicle_type where ADMIN_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				byte photo[];
				Blob blob;
				int i=1;
				while(rs.next()){
					
					VehicleType vehicle=new VehicleType();
					vehicle.setVEHICLE_SEQ_NO(i);
					vehicle.setBRAND(rs.getString("BRAND"));
					vehicle.setMODEL(rs.getString("MODEL"));
					vehicle.setADMIN_ID(rs.getString("ADMIN_ID"));
					
					blob=rs.getBlob("IMAGE");
					photo=blob.getBytes(1, (int)blob.length());
					String photo1=Base64.encode(photo);
					vehicle.setIMAGE(photo1);
					
					vehicleList.add(vehicle);
					
					i++;
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return vehicleList;
	}

	public Set<String> getVehicleType() {
		// TODO Auto-generated method stub
	Set<String> vehicleSet=new TreeSet<String>();
		
		PreparedStatement pst=null;

		
			try {
				String query="select * from vehicle_type";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					
					vehicleSet.add(rs.getString("BRAND"));
					
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return vehicleSet;
	}


	public List<VehicleType> getAdminVehicleType() {
		// TODO Auto-generated method stub
		List<VehicleType> vehicleList=new ArrayList<VehicleType>();
		PreparedStatement pst=null;

		
			try {
				String query="select * from vehicle_type";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				byte photo[];
				Blob blob;
				while(rs.next()){
					
					VehicleType vehicle=new VehicleType();
					
					vehicle.setBRAND(rs.getString("BRAND"));
					vehicle.setMODEL(rs.getString("MODEL"));
					blob=rs.getBlob("IMAGE");
					photo=blob.getBytes(1, (int)blob.length());
					String photo1=Base64.encode(photo);
					
					vehicle.setIMAGE(photo1);
					
					vehicleList.add(vehicle);
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return vehicleList;
	}

	public Map<String, Set<String>> getAdCabModel(String brand) {
		// TODO Auto-generated method stub
		Map<String,Set<String>> map=new TreeMap<String,Set<String>>();
		
		Set<String> modelset=new TreeSet<String>();
		Set<String> noOfPasset=new TreeSet<String>();
		
		PreparedStatement pst=null;

			try {
				String query="SELECT MODEL,NO_OF_PASSENGER FROM vehicle_type where BRAND='"+brand+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					modelset.add(rs.getString("MODEL"));
					noOfPasset.add(rs.getString("NO_OF_PASSENGER"));
					
				}
				map.put("model", modelset);
				map.put("noOfPas", noOfPasset);
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return map;
	}
	
	public Set<String> getNoOfPassenger(String model) {
		// TODO Auto-generated method stub
Set<String> noOfPassenger=new TreeSet<String>();
		
		PreparedStatement pst=null;

			try {
				String query="SELECT NO_OF_PASSENGER FROM vehicle_type where MODEL='"+model+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					noOfPassenger.add(rs.getString("NO_OF_PASSENGER"));
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return noOfPassenger;
	}
	
	public Set<String> getVehicleModel() {
		// TODO Auto-generated method stub
	Set<String> vehicleSet=new TreeSet<String>();
		
		PreparedStatement pst=null;

		
			try {
				String query="select MODEL from vehicle_type";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					
					vehicleSet.add(rs.getString("MODEL"));
					
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return vehicleSet;

}

	public List<AddCab> getAdminCab(String email) {
		// TODO Auto-generated method stub
		List<AddCab> cabList=new ArrayList<AddCab>();
		PreparedStatement pst=null;

		
			try {
				String query="select * from add_cab where CAB_OWNER_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					
					AddCab cab=new AddCab();
					cab.setCAB_REG_NO(rs.getString("CAB_REG_NO"));
					cab.setCAB_GEN_ID(rs.getString("CAB_GEN_ID"));
					cab.setCAB_BRAND(rs.getString("CAB_BRAND"));
					cab.setCAB_MODEL(rs.getString("CAB_MODEL"));
					cab.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					cab.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					cabList.add(cab);
				
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabList;
	}

	public AddCab viewAdCab(String email, String cabId) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		
		AddCab addCab=new AddCab();
		Blob blob;
		Blob blob1;
		Blob blob2;
		byte[] image;
		byte[] rcDoc;
		byte[] insDoc;
			try {
				String query="SELECT * FROM add_cab where CAB_REG_NO='"+cabId+"' and CAB_OWNER_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					addCab.setCAB_GEN_ID(rs.getString("CAB_GEN_ID"));
					addCab.setCAB_REG_NO(rs.getString("CAB_REG_NO"));
					addCab.setCAB_BRAND(rs.getString("CAB_BRAND"));
					addCab.setCAB_MODEL(rs.getString("CAB_MODEL"));
					addCab.setADDRESS(rs.getString("ADDRESS"));
					addCab.setBODY_TYPE(rs.getString("BODY_TYPE"));
					addCab.setCAB_SEQ_ID(rs.getInt("CAB_SEQ_ID"));
					addCab.setCERTIFIED_COMP_NAME(rs.getString("CERTIFIED_COMP_NAME"));
					addCab.setCITY(rs.getString("CITY"));
					addCab.setCOLOR(rs.getString("COLOR"));
					addCab.setCURRENT_MILEAGE(rs.getString("CURRENT_MILEAGE"));
					addCab.setDISTRICT(rs.getString("DISTRICT"));
					addCab.setFUEL_TYPE(rs.getString("FUEL_TYPE"));
					addCab.setINSURENCE_COMP_NAME(rs.getString("INSURENCE_COMP_NAME"));
					addCab.setKM_DRIVEN(rs.getString("KM_DRIVEN"));
					addCab.setMOBILE_NO(rs.getString("MOBILE_NO"));
					addCab.setMODEL_YEAR(rs.getString("MODEL_YEAR"));
					addCab.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					addCab.setPINCODE(rs.getString("PINCODE"));
					addCab.setREGISTERED_CITY(rs.getString("REGISTERED_CITY"));
					addCab.setREGISTERED_STATE(rs.getString("REGISTERED_STATE"));
					addCab.setREGISTERED_YEAR(rs.getString("REGISTERED_YEAR"));
					addCab.setSTATE(rs.getString("STATE"));
					addCab.setSTATUS(rs.getString("STATUS"));
					addCab.setTRANSMISSION(rs.getString("TRANSMISSION"));
					
					blob=rs.getBlob("CAB_PHOTO");
					blob1=rs.getBlob("RC_DOC");
					blob2=rs.getBlob("INSURANCE_DOC");
					
					image=blob.getBytes(1, (int)blob.length());
					rcDoc=blob1.getBytes(1, (int)blob1.length());
					insDoc=blob2.getBytes(1, (int)blob2.length());
					
					String photo=Base64.encode(image);
					String rcDocument=Base64.encode(rcDoc);
					String insuranceDoc=Base64.encode(insDoc);
					
					addCab.setCAB_PHOTO(photo);
					addCab.setRC_DOC(rcDocument);
					addCab.setINSURANCE_DOC(insuranceDoc);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return addCab;
	}

	public List<CabRoute> viewAdCabRout(String email, String cabId) {
		// TODO Auto-generated method stub
		List<CabRoute> routeList=new ArrayList<CabRoute>();
		PreparedStatement pst=null;

		String query=null;
		if(cabId!=null){
			query="select * from cab_route where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"'";	
		}else{
			query="select * from cab_route where CAB_OWNER_ID='"+email+"'";
		}
		
			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				byte photo[];
				Blob blob;
				while(rs.next()){
					
					CabRoute route=new CabRoute();
					
					route.setCAB_MODEL(rs.getString("CAB_MODEL"));
					route.setSOURCE_ADDRESS(rs.getString("SOURCE_ADDRESS"));
					route.setDESTINATION(rs.getString("DESTINATION"));
					route.setPICK_UP_DATE(rs.getString("PICK_UP_DATE"));
					route.setFROM_LOCATION(rs.getString("FROM_LOCATION"));
					route.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					route.setPRICE(rs.getString("PRICE"));
					route.setPRICE_PER_KM(rs.getString("PRICE_PER_KM"));
					route.setCAB_ID(rs.getString("CAB_ID"));
					route.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					route.setAVAILABILITY(rs.getString("AVAILABILITY"));
					route.setSTATUS(rs.getString("STATUS"));
				
					routeList.add(route);
				
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return routeList;
	}
	
	public List<AddCab> getCabDetails(String query) {
		// TODO Auto-generated method stub
		List<AddCab> cabList=new ArrayList<AddCab>();
		PreparedStatement pst=null;

		
			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					
					AddCab cab=new AddCab();
					cab.setCAB_REG_NO(rs.getString("CAB_REG_NO"));
					cab.setCAB_GEN_ID(rs.getString("CAB_GEN_ID"));
					cab.setCAB_BRAND(rs.getString("CAB_BRAND"));
					cab.setCAB_MODEL(rs.getString("CAB_MODEL"));
					cab.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					cab.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					cab.setSTATUS(rs.getString("STATUS"));
					cabList.add(cab);
				
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabList;
	}

	public List<AddCab> getAdminCab(String email, String cabId) {
		// TODO Auto-generated method stub
		String query="";
		
		if(cabId!=null && !cabId.equals("") && !cabId.equals("All")){
			query="SELECT * FROM add_cab where CAB_REG_NO='"+cabId+"' and CAB_OWNER_ID='"+email+"'";
		}else if(cabId==null||cabId.equals("")||cabId.equals("All")){
			query="SELECT * FROM add_cab where CAB_OWNER_ID='"+email+"'";
		}
		List<AddCab> cabList=getCabDetails(query);
		
		return cabList;
	}

	public List<CabBook> getCabBookingDetails(String query) {
		// TODO Auto-generated method stub
		List<CabBook> bookList=new ArrayList<CabBook>();
		PreparedStatement pst=null;

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					CabBook cab=new CabBook();
					
					cab.setBOOKING_ID(rs.getString("BOOKING_ID"));
					cab.setCONTACT_NO(rs.getString("CONTACT_NO"));
					cab.setPICK_UP_ADDRESS(rs.getString("PICK_UP_ADDRESS"));
					cab.setBOOKING_STATUS(rs.getString("BOOKING_STATUS"));
					cab.setBOOKING_DATE(new SQLDate().getInDate(rs.getString("BOOKING_DATE")));
					cab.setCAB_ID(rs.getString("CAB_ID"));
					cab.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					bookList.add(cab);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return bookList;
	}

	public List<CabBook> serachCabBooking(String cabId, String email, String date1,String date2) {
		// TODO Auto-generated method stub
		String query="";
		
		if(date1!=null && !date1.equals("") && !date2.equals("")){
			
			query="SELECT * FROM cab_booking where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and BOOKING_DATE between '"+date1+"' and '"+date2+"'";
		
		}else if(date1!=null && !date1.equals("")){
			
			query="SELECT * FROM cab_booking where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and BOOKING_DATE ='"+date1+"'";

		}else if(date2!=null && !date2.equals("")){
			
			query="SELECT * FROM cab_booking where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and BOOKING_DATE ='"+date2+"'";

		}else{
			
			query="SELECT * FROM cab_booking where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"'";

		}
		
		
		List<CabBook> cabBookingList=getCabBookingDetails(query);
		
		return cabBookingList;
	}

	public String getCabBookingCount(String cabId, String ownerId) {
		// TODO Auto-generated method stub
		String count="";
		PreparedStatement pst=null;

		
			try {
				String query="select count(*) from cab_booking where CAB_ID='"+cabId+"' and CAB_OWNER_ID='"+ownerId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
			    count=rs.getString("count(*)");
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return count;
	}

	public String getCandidatename(String email) {
		// TODO Auto-generated method stub
		String name="";
		PreparedStatement pst=null;

		
			try {
				String query="select CANDIDATE_NAME from registration where EMAIL_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
			    name=rs.getString("CANDIDATE_NAME");
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return name;
	}

	public List<AssignDriverCab> viewCabDriver(String email, String driverId) {
		// TODO Auto-generated method stub
		List<AssignDriverCab> assignList=new ArrayList<AssignDriverCab>();
		PreparedStatement pst=null;

			try {
				String query="SELECT * FROM assign_driver_cab where CAB_OWNER_ID='"+email+"' and DRIVER_ID='"+driverId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					AssignDriverCab assignDriver=new AssignDriverCab();
					
					assignDriver.setASSIGN_ID(rs.getInt("ASSIGN_ID"));
					assignDriver.setASSIGN_DATE(rs.getString("ASSIGN_DATE"));
					assignDriver.setASSIGN_TIME(rs.getString("ASSIGN_TIME"));
					assignDriver.setCAB_ID(rs.getString("CAB_ID"));
					assignDriver.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					assignDriver.setDRIVER_ID(rs.getString("DRIVER_ID"));
					assignDriver.setSTATUS(rs.getString("STATUS"));
					
					assignList.add(assignDriver);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return assignList;
	}

	public List<Travellers> searchAdTravelerPost(String email,String trId) {
		// TODO Auto-generated method stub
		String query="";
		
		if(trId!=null && !trId.equals("") && !trId.equals("All")){
			
			query="select * from travellers where TRAVELLER_EMAIL='"+email+"' and TRAVELING_ID='"+trId+"'";
		}else{
			query="select * from travellers where TRAVELLER_EMAIL='"+email+"'";
		}
		List<Travellers> postList=new TravellerDAOImpl().searchTraveller(query);
		return postList;
	}

	public Set<String> getTravelerPostingId(String email) {
		// TODO Auto-generated method stub
		Set<String> trList=new TreeSet<String>();
		PreparedStatement pst=null;

			try {
				String query="SELECT TRAVELING_ID FROM travellers where TRAVELLER_EMAIL='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
				trList.add(rs.getString("TRAVELING_ID"));
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return trList;
	}

	public String getTravelerBookingCount(String email, String trId) {
		// TODO Auto-generated method stub
		String count="";
		PreparedStatement pst=null;

		
			try {
				String query="select count(*) from traveler_booking where TRAVELER_ID='"+trId+"' and TRAVELER_EMAIL='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
			    count=rs.getString("count(*)");
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return count;
	}

	public List<TravelerBooking> searchTravellerBooking(String email, String trId, String date1, String date2) {
		// TODO Auto-generated method stub
		
		String query="";
		
	if(date1!=null && !date1.equals("") && !date2.equals("")){
			
			query="SELECT * FROM traveler_booking where TRAVELER_EMAIL='"+email+"' and TRAVELER_ID='"+trId+"' and BOOKING_DATE between '"+date1+"' and '"+date2+"'";
		
		}else if(date1!=null && !date1.equals("")){
			
			query="SELECT * FROM traveler_booking where TRAVELER_EMAIL='"+email+"' and TRAVELER_ID='"+trId+"' and BOOKING_DATE ='"+date1+"'";

		}else if(date2!=null && !date2.equals("")){
			
			query="SELECT * FROM traveler_booking where TRAVELER_EMAIL='"+email+"' and TRAVELER_ID='"+trId+"' and BOOKING_DATE ='"+date2+"'";

		}else{
			
			query="SELECT * FROM traveler_booking where TRAVELER_EMAIL='"+email+"' and TRAVELER_ID='"+trId+"'";

		}
	
	List<TravelerBooking> bookList=getTravelerBookingDetails(query);
	
	return bookList;
	
	}

	public List<TravelerBooking> getTravelerBookingDetails(String query) {
		// TODO Auto-generated method stub
		List<TravelerBooking> bookList=new ArrayList<TravelerBooking>();
		PreparedStatement pst=null;

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					TravelerBooking traveler=new TravelerBooking();
					
					traveler.setBOOKING_SEQ_ID(rs.getInt("BOOKING_SEQ_ID"));
					traveler.setBOOKING_ID(rs.getString("BOOKING_ID"));
					traveler.setCAB_ID(rs.getString("CAB_ID"));
					traveler.setBOOKING_DATE(rs.getString("BOOKING_DATE"));
					traveler.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					traveler.setOFFER_PRICE(rs.getString("OFFER_PRICE"));
					traveler.setSTATUS(rs.getString("STATUS"));
					traveler.setTRAVELER_EMAIL(rs.getString("TRAVELER_EMAIL"));
					traveler.setTRAVELER_ID(rs.getString("TRAVELER_ID"));
				
					bookList.add(traveler);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return bookList;
	}
	
	
}
