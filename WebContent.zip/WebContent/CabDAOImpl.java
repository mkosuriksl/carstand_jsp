package com.zoro.daoImpl;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.owtelse.codec.Base64;
import com.zoro.dao.CabDAO;
import com.zoro.dbutil.DBConnection;
import com.zoro.dbutil.IdGen;
import com.zoro.dto.AddCab;
import com.zoro.dto.AssignDriverCab;
import com.zoro.dto.CabBook;
import com.zoro.dto.CabHomeSearch;
import com.zoro.dto.CabRoute;
import com.zoro.dto.DriverBean;
import com.zoro.dto.RegistrationBean;
import com.zoro.dto.TravelerBooking;
import com.zoro.utility.BookingId;
import com.zoro.utility.CabId;
import com.zoro.utility.DriverId;
import com.zoro.utility.SQLDate;

public class CabDAOImpl implements CabDAO {
	
	private   Connection con=null;
	private int noOfRecords=0;

	public Set<String> getCabModel() {
		// TODO Auto-generated method stub
		
		Set<String> cabModel=new TreeSet<String>();
		
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_MODEL FROM cab_route;";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cabModel.add(rs.getString("CAB_MODEL"));
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabModel;
	}

	public Set<String> getNoOfPassenger(String model) {
		// TODO Auto-generated method stub
Set<String> noOfPassenger=new TreeSet<String>();
		
		PreparedStatement pst=null;

			try {
				String query="SELECT NO_OF_PASSENGER FROM cab_route where CAB_MODEL='"+model+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					noOfPassenger.add(rs.getString("NO_OF_PASSENGER"));
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return noOfPassenger;
	}

	public String addCab(AddCab addCab,InputStream rcDoc,InputStream insuranceDoc,InputStream cabPhoto) {
		// TODO Auto-generated method stub
		String msg=null;
		PreparedStatement pst=null;
		
		try{
			String id=new IdGen().getId("CAB_ID");
			String cabId=new CabId().CabId(id);
			
			String query="insert into add_cab values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURDATE())";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1, addCab.getCAB_SEQ_ID());
			pst.setString(2, addCab.getCAB_REG_NO());
			pst.setString(3, addCab.getCAB_BRAND());
			pst.setString(4, addCab.getCAB_MODEL());
			pst.setString(5, addCab.getMODEL_YEAR());
			pst.setString(6, addCab.getCURRENT_MILEAGE());
			pst.setString(7, addCab.getFUEL_TYPE());
			pst.setString(8, addCab.getBODY_TYPE());
			pst.setString(9, addCab.getTRANSMISSION());
			pst.setString(10, addCab.getKM_DRIVEN());
			pst.setString(11, addCab.getNO_OF_PASSENGER());
			pst.setString(12, addCab.getCOLOR());
			pst.setString(13, addCab.getINSURENCE_COMP_NAME());
			pst.setString(14, addCab.getCERTIFIED_COMP_NAME());
			pst.setString(15, addCab.getREGISTERED_YEAR());
			pst.setString(16, addCab.getREGISTERED_CITY());
			pst.setString(17, addCab.getREGISTERED_STATE());
			
			pst.setBlob(18, rcDoc);
			pst.setBlob(19, insuranceDoc);
			pst.setBlob(20, cabPhoto);
			
			pst.setString(21, addCab.getCAB_OWNER_ID());
			pst.setString(22, cabId);
			pst.setString(23, "ACTIVE");
			pst.setString(24, addCab.getMOBILE_NO());
			pst.setString(25, addCab.getADDRESS());
			pst.setString(26, addCab.getCITY());
			pst.setString(27, addCab.getSTATE());
			pst.setString(28, addCab.getDISTRICT());
			pst.setString(29, addCab.getPINCODE());
			
		
			int i=pst.executeUpdate();
			
			if(i>0){
				
				msg="Cab Added Successfully..";
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}finally {
			
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
		}
		
		return msg;
	}

	public String getCabRegNo(String cabRegNo) {
		// TODO Auto-generated method stub
		
		String regNo=null;
		String msg=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_REG_NO FROM add_cab where CAB_REG_NO='"+cabRegNo+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					regNo=rs.getString("CAB_REG_NO");
					
				}
				if(regNo!=null){
					
					msg="This Cab Number Is Allready Added In TravelZ";
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return msg;
		
	}

	public String addCabRoutes(CabRoute cabRoute) {
		// TODO Auto-generated method stub
		
		String msg=null;
		PreparedStatement pst=null;
		
		Date date1=new Date();
		DateFormat time=new SimpleDateFormat("hh:mm:ss");
		String time1=time.format(date1);
		
		try{
			String id=new IdGen().getId("ROUTE_GEN_ID");
			String routeId=new CabId().routeId(id);
			String date=new SQLDate().getInDate(cabRoute.getPICK_UP_DATE());
			
			String query="insert into cab_route values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1, cabRoute.getCAB_ROUTE_ID());
			pst.setString(2, cabRoute.getCAB_MODEL());
			pst.setString(3, cabRoute.getSOURCE_ADDRESS());
			pst.setString(4, cabRoute.getDESTINATION());
			pst.setString(5, date);
			pst.setString(6, cabRoute.getFROM_LOCATION());
			pst.setString(7, cabRoute.getNO_OF_PASSENGER());
			pst.setString(8, cabRoute.getPRICE());
			pst.setString(9, cabRoute.getPRICE_PER_KM());
			pst.setString(10, cabRoute.getCAB_ID());
			pst.setString(11, cabRoute.getCAB_OWNER_ID());
			pst.setString(12, "ACTIVE");
			pst.setString(13, "YES");
			pst.setString(14, routeId);
			pst.setString(15, time1);
			
		
			int i=pst.executeUpdate();
			
			
			if(i>0){
				
				msg="Cab Route Added Successfully..";
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}finally {
			
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
		}
		
		return msg;
		
	}

	public Set<String> CabRegNo(String email) {
		// TODO Auto-generated method stub
		Set<String> regNo=new TreeSet<String>();
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_REG_NO FROM add_cab where CAB_OWNER_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					regNo.add(rs.getString("CAB_REG_NO"));
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return regNo;
	}

	public Map<String,String> getCabModel(String cabRegNo) {
		// TODO Auto-generated method stub
		Map<String,String> regNo=new TreeMap<String,String>();
		String msg=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_MODEL,NO_OF_PASSENGER FROM add_cab where CAB_REG_NO='"+cabRegNo+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					regNo.put("cabModel",rs.getString("CAB_MODEL"));
					regNo.put("noOfPas", rs.getString("NO_OF_PASSENGER"));
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return regNo;
	}

	public String getCabIdFromCabRoute(String cabId) {
		// TODO Auto-generated method stub
		String msg=null;
		String cabRegId=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_ID FROM cab_route where CAB_ID='"+cabId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cabRegId=rs.getString("CAB_ID");
					
				}
				if(cabRegId!=null){
					
					msg="This Cab Number Is Allready Added In TravelZ Please Update Your Route";
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return msg;
	}

	public List<CabRoute> searchCabRoutes(String email,String cabId) {
		// TODO Auto-generated method stub
		List<CabRoute> cabRoute=new ArrayList<CabRoute>();
		String msg=null;
		PreparedStatement pst=null;
		
		String query=null;
		
		if(cabId!=null){
			
			query="SELECT * FROM cab_route where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and STATUS='ACTIVE'";
			
		}else{
			
			query="SELECT * FROM cab_route where CAB_OWNER_ID='"+email+"' and STATUS='ACTIVE'";
			
		}

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					CabRoute routeBean=new CabRoute();
					
					routeBean.setCAB_ROUTE_ID(rs.getInt("CAB_ROUTE_ID"));
					routeBean.setCAB_MODEL(rs.getString("CAB_MODEL"));
					routeBean.setSOURCE_ADDRESS(rs.getString("SOURCE_ADDRESS"));
					routeBean.setDESTINATION(rs.getString("DESTINATION"));
					routeBean.setPICK_UP_DATE(rs.getString("PICK_UP_DATE"));
					routeBean.setFROM_LOCATION(rs.getString("FROM_LOCATION"));
					routeBean.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					routeBean.setPRICE(rs.getString("PRICE"));
					routeBean.setPRICE_PER_KM(rs.getString("PRICE_PER_KM"));
					routeBean.setCAB_ID(rs.getString("CAB_ID"));
					routeBean.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					routeBean.setSTATUS(rs.getString("STATUS"));
					routeBean.setAVAILABILITY(rs.getString("AVAILABILITY"));
					routeBean.setROUTE_GEN_ID(rs.getString("ROUTE_GEN_ID"));
					routeBean.setROUTE_ADDED_TIME(rs.getString("ROUTE_ADDED_TIME"));
					
					cabRoute.add(routeBean);
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabRoute;
	}

	public String updateCabRoutes(CabRoute cabRoute) {
		// TODO Auto-generated method stub
		
		String msg=null;
		PreparedStatement pst=null;
		
		Date date1=new Date();
		DateFormat time=new SimpleDateFormat("hh:mm:ss");
		String time1=time.format(date1);
		
		try{
			String id=new IdGen().getId("ROUTE_GEN_ID");
			String routeId=new CabId().routeId(id);
			/*set SQL_SAFE_UPDATES=0; */
			String date=new SQLDate().getInDate(cabRoute.getPICK_UP_DATE());
			
			String query="insert into cab_route values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1, cabRoute.getCAB_ROUTE_ID());
			pst.setString(2, cabRoute.getCAB_MODEL());
			pst.setString(3, cabRoute.getSOURCE_ADDRESS());
			pst.setString(4, cabRoute.getDESTINATION());
			pst.setString(5, date);
			pst.setString(6, cabRoute.getFROM_LOCATION());
			pst.setString(7, cabRoute.getNO_OF_PASSENGER());
			pst.setString(8, cabRoute.getPRICE());
			pst.setString(9, cabRoute.getPRICE_PER_KM());
			pst.setString(10, cabRoute.getCAB_ID());
			pst.setString(11, cabRoute.getCAB_OWNER_ID());
			pst.setString(12, "ACTIVE");
			pst.setString(13, "YES");
			pst.setString(14, routeId);
			pst.setString(15, time1);
			
			int i=pst.executeUpdate();
			if(i>0){
				msg="cab route Updated Successfully....";
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return msg;
	}

	public String addDriver(DriverBean addDriver,InputStream doc,InputStream photo) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message="";
		SQLDate date=new SQLDate();
		String date1=date.getInDate(addDriver.getDOB());
		String date2=date.getInDate(addDriver.getEXPIRY_DATE());
		
		try{ 
			
			String query="insert into add_driver values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURDATE())";
			String id1=new IdGen().getId("DRIVER_ID");
			DriverId did=new DriverId();
			String driverId=did.driverId(id1);
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);
		    pst.setInt(1, addDriver.getSEQ_DRIVER_ID());
		    pst.setString(2, addDriver.getFIRST_NAME());
		    pst.setString(3, addDriver.getLAST_NAME());
		    pst.setString(4, addDriver.getEMAIL());
		    pst.setString(5, addDriver.getMOBILE_NO());
		    pst.setString(6, date1);
		    pst.setString(7, addDriver.getADDRESS());
		    pst.setString(8, addDriver.getSTREET());
		    pst.setString(9, addDriver.getCITY());
		    pst.setString(10, addDriver.getSTATE());
		    pst.setString(11, addDriver.getDISTRICT());
		    pst.setString(12, addDriver.getPINCODE());
		    pst.setString(13, addDriver.getREGISTERED_STATE());
		    pst.setString(14, addDriver.getLICENSE_NO());
		    pst.setString(15, addDriver.getLICENSE_TYPE());
		    pst.setString(16, date2);
		    pst.setString(17, addDriver.getDRIVING_EXP());
		    pst.setString(18, addDriver.getPERMIT_TYPE());
		    pst.setString(19, addDriver.getWITHIN_RANGE());
		    pst.setString(20, addDriver.getADHAR_NO());
		    pst.setString(21, addDriver.getPAN_NO());
		    pst.setBlob(22, doc);
		    pst.setBlob(23, photo);
		    pst.setString(24,addDriver.getM_USER_ID());
		    pst.setString(25, "AVAILABLE");
		    pst.setString(26, driverId);
		    pst.setString(27, "ACTIVE");
		    pst.setString(28, addDriver.getJOB_TYPE());

		    int i=pst.executeUpdate();
		    if(i>0){

				message="Driver Added SuccessFully......";
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public Set<String> getDriverId(String email) {
		// TODO Auto-generated method stub
		Set<String> driverId=new TreeSet<String>();
		PreparedStatement pst=null;

			try {
				String query="SELECT DRIVER_ID FROM add_driver where M_USER_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					driverId.add(rs.getString("DRIVER_ID"));
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driverId;
	}

	public List<DriverBean> searchDriver(String email, String driverId) {
		// TODO Auto-generated method stub
		List<DriverBean> driverList=new ArrayList<DriverBean>();
		String msg=null;
		PreparedStatement pst=null;
		
		String query=null;
		Blob blob1,blob2;
		byte[] licDoc=null,photo=null;
		String licenseDoc=null,image=null;
		if(driverId!=null){
			
			query="SELECT * FROM add_driver where M_USER_ID='"+email+"' and DRIVER_ID='"+driverId+"'";
			
		}else{
			
			query="SELECT * FROM add_driver where M_USER_ID='"+email+"'";
			
		}

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					DriverBean driver=new DriverBean();
					
					driver.setFIRST_NAME(rs.getString("FIRST_NAME"));
					driver.setLAST_NAME(rs.getString("LAST_NAME"));
					driver.setEMAIL(rs.getString("EMAIL"));
					driver.setMOBILE_NO(rs.getString("MOBILE_NO"));
					driver.setDRIVER_ID(rs.getString("DRIVER_ID"));
					driver.setDOB(rs.getString("DOB"));
					driver.setADDRESS(rs.getString("ADDRESS"));
					driver.setSTREET(rs.getString("STREET"));
					driver.setCITY(rs.getString("CITY"));
					driver.setSTATE(rs.getString("STATE"));
					driver.setDISTRICT(rs.getString("DISTRICT"));
					driver.setPINCODE(rs.getString("PINCODE"));
					driver.setREGISTERED_STATE(rs.getString("REGISTERED_STATE"));
					driver.setLICENSE_NO(rs.getString("LICENSE_NO"));
					driver.setLICENSE_TYPE(rs.getString("LICENSE_TYPE"));
					driver.setEXPIRY_DATE(rs.getString("EXPIRY_DATE"));
					driver.setPERMIT_TYPE(rs.getString("PERMIT_TYPE"));
					driver.setWITHIN_RANGE(rs.getString("WITHIN_RANGE"));
					driver.setADHAR_NO(rs.getString("ADHAR_NO"));
					driver.setPAN_NO(rs.getString("PAN_NO"));
					driver.setJOB_TYPE(rs.getString("JOB_TYPE"));
					driver.setDRIVING_EXP(rs.getString("DRIVING_EXP"));
					driver.setREGISTERED_DATE(rs.getString("REGISTERED_DATE"));
					driver.setSTATUS(rs.getString("STATUS"));
					driver.setOWNER_ID(rs.getString("M_USER_ID"));
					
					blob1=rs.getBlob("LICENSE_DOC");
					blob2=rs.getBlob("PHOTO");
					if(blob1!=null){
					licDoc=blob1.getBytes(1, (int)blob1.length());
					licenseDoc=Base64.encode(licDoc);
					}
					if(blob2!=null){
					photo=blob2.getBytes(1, (int)blob2.length());
					image=Base64.encode(photo);
					}
					
					driver.setLICENSE_DOC(licenseDoc);
					driver.setPHOTO(image);
					
					driverList.add(driver);
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driverList;
	}

	public String updateDriver(DriverBean driver) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		String date2=new SQLDate().getSQLDate(driver.getEXPIRY_DATE());
		
		try{ 
			
			String query="update add_driver set FIRST_NAME=?,LAST_NAME=?,MOBILE_NO=?,ADDRESS=?,STREET=?,CITY=?,STATE=?,DISTRICT=?,PINCODE=?,REGISTERED_STATE=?,LICENSE_NO=?,LICENSE_TYPE=?,EXPIRY_DATE=?,DRIVING_EXP=?,PERMIT_TYPE=?,WITHIN_RANGE=?,ADHAR_NO=?,PAN_NO=?,JOB_TYPE=? where M_USER_ID='"+driver.getM_USER_ID()+"' and EMAIL='"+driver.getEMAIL()+"'";
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);
		    pst.setString(1, driver.getFIRST_NAME());
		    pst.setString(2, driver.getLAST_NAME());
		    pst.setString(3, driver.getMOBILE_NO());
//		    pst.setString(6, date1);
		    pst.setString(4, driver.getADDRESS());
		    pst.setString(5, driver.getSTREET());
		    pst.setString(6, driver.getCITY());
		    pst.setString(7, driver.getSTATE());
		    pst.setString(8, driver.getDISTRICT());
		    pst.setString(9, driver.getPINCODE());
		    pst.setString(10, driver.getREGISTERED_STATE());
		    pst.setString(11, driver.getLICENSE_NO());
		    pst.setString(12, driver.getLICENSE_TYPE());
		    pst.setString(13, date2);
		    pst.setString(14, driver.getDRIVING_EXP());
		    pst.setString(15, driver.getPERMIT_TYPE());
		    pst.setString(16, driver.getWITHIN_RANGE());
		    pst.setString(17, driver.getADHAR_NO());
		    pst.setString(18, driver.getPAN_NO());
//		    pst.setBlob(22, doc);
//		    pst.setBlob(23, photo);
		    pst.setString(19, driver.getJOB_TYPE());

		    int i=pst.executeUpdate();
		    if(i>0){

				message="Driver Updated SuccessFully......";
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public Map<String, String> getDriverName(String driverId) {
		// TODO Auto-generated method stub
		Map<String,String> driver=new TreeMap<String,String>();
		String msg=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT FIRST_NAME,LAST_NAME,EMAIL FROM add_driver where DRIVER_ID='"+driverId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					driver.put("driverName",rs.getString("FIRST_NAME")+"  "+rs.getString("LAST_NAME"));
					driver.put("driverEmail", rs.getString("EMAIL"));
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driver;
	}

	public String assignDriverToCab(String cabId, String driverId, String userId) {
		// TODO Auto-generated method stub
		String msg=null;
		PreparedStatement pst=null;
		
		try{
			Date date=new Date();
			DateFormat format=new SimpleDateFormat("dd-mm-yyyy");
			DateFormat formatTime=new SimpleDateFormat("HH:mm:ss");
			String sysDate=format.format(date);
			String sysTime=formatTime.format(date);
			
			String query="insert into assign_driver_cab values(?,?,?,?,?,?,?)";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
			
			pst.setInt(1,0);
			pst.setString(2, driverId);
			pst.setString(3, cabId);
			pst.setString(4, userId);
			pst.setString(5, sysDate);
			pst.setString(6, sysTime);
			pst.setString(7, "ACTIVE");
			
			int i=pst.executeUpdate();
			
			
			if(i>0){
				
				msg="Assigned Driver To Cab Successfully..";
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}finally {
			
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
		}
		
		return msg;
	}

	public String getAssignedValue(String cabId,String email,String driverId1) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String driverId=null;

			try {
				String query="SELECT DRIVER_ID FROM assign_driver_cab where CAB_ID='"+cabId+"' and CAB_OWNER_ID='"+email+"' and DRIVER_ID='"+driverId1+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					driverId=rs.getString("DRIVER_ID");
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driverId;
	}

	public String getDriverEmail(String driverEmail, String userId) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String driverId=null;

			try {
				String query="SELECT EMAIL FROM add_driver where EMAIL='"+driverEmail+"' and M_USER_ID='"+userId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					driverId=rs.getString("DRIVER_ID");
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driverId;
	}

	public Set<AssignDriverCab> searchAssignedDriver(String cabId, String userId) {
		// TODO Auto-generated method stub
		Set<AssignDriverCab> driverSet=new HashSet<AssignDriverCab>();
		String msg=null;
		PreparedStatement pst=null;
		
		String query=null;
		
		if(cabId!=null && !cabId.equals("null")){
			
			query="SELECT * FROM assign_driver_cab where CAB_ID='"+cabId+"' and CAB_OWNER_ID='"+userId+"' group by ASSIGN_ID";
			
		}else{
			
			query="SELECT * FROM assign_driver_cab where CAB_OWNER_ID='"+userId+"' group by ASSIGN_ID";
			
		}

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					AssignDriverCab assignDriver=new AssignDriverCab();
					
					assignDriver.setASSIGN_ID(rs.getInt("ASSIGN_ID"));
					assignDriver.setCAB_ID(rs.getString("CAB_ID"));
					assignDriver.setDRIVER_ID(rs.getString("DRIVER_ID"));
					assignDriver.setASSIGN_DATE(rs.getString("ASSIGN_DATE"));
					assignDriver.setASSIGN_TIME(rs.getString("ASSIGN_TIME"));
					assignDriver.setSTATUS(rs.getString("STATUS"));
					
					driverSet.add(assignDriver);
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driverSet;
	}

	public String activateDriver(String cabId, String assignId, String userId, String status) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			
			String query="update assign_driver_cab set STATUS='"+status+"' where CAB_ID='"+cabId+"' and ASSIGN_ID='"+assignId+"' and CAB_OWNER_ID='"+userId+"'";
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);

		    int i=pst.executeUpdate();
		    if(i>0){
		    	if(status.equals("INACTIVE")){
				message="Driver Inactivated SuccessFully......";
		    	}else{
		    		message="Driver Activated SuccessFully..";
		    	}
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public String getCabRegNo(String cabRegNo, String email) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String cabId=null;
			try {
				String query="SELECT CAB_REG_NO FROM add_cab where CAB_OWNER_ID='"+email+"' and CAB_REG_NO='"+cabRegNo+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cabId=rs.getString("CAB_REG_NO");
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabId;
	}

	public Map<String,String> getAssignedStatus(String driverId,String cabId) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		Map<String,String> map=new TreeMap<String,String>();
			try {
				String query="SELECT STATUS,CAB_ID FROM assign_driver_cab where DRIVER_ID='"+driverId+"' and CAB_ID!='"+cabId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					map.put("status",rs.getString("STATUS"));
					map.put("cabId",rs.getString("CAB_ID"));
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return map;
	}

	public Set<String> getBookingCabId(String email) {
		// TODO Auto-generated method stub
		Set<String> cabSet=new TreeSet<String>();
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_ID FROM traveler_booking where CAB_OWNER_ID='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cabSet.add(rs.getString("CAB_ID"));
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabSet;
	}

	public List<TravelerBooking> getBookedTraveller(String email,String cabId) {
		// TODO Auto-generated method stub
		List<TravelerBooking> cabSet=new ArrayList<TravelerBooking>();
		PreparedStatement pst=null;
		
		String query=null;
		if(cabId!=null && !cabId.equals("null")){
			query="SELECT * FROM traveler_booking where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"'";
		}else{
			query="SELECT * FROM traveler_booking where CAB_OWNER_ID='"+email+"'";
		}
			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					TravelerBooking bean=new TravelerBooking();
					bean.setBOOKING_SEQ_ID(rs.getInt("BOOKING_SEQ_ID"));
					bean.setCAB_ID(rs.getString("CAB_ID"));
					bean.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					bean.setTRAVELER_ID(rs.getString("TRAVELER_ID"));
					bean.setTRAVELER_EMAIL(rs.getString("TRAVELER_EMAIL"));
					bean.setOFFER_PRICE(rs.getString("OFFER_PRICE"));
					bean.setBOOKING_ID(rs.getString("BOOKING_ID"));
					bean.setBOOKING_DATE(new SQLDate().getInDate(rs.getString("BOOKING_DATE")));
					bean.setSTATUS(rs.getString("STATUS"));
					cabSet.add(bean);
					
				}
	
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabSet;
	}

	public Map<String,Set<String>> getFromToVehicleType() {
		// TODO Auto-generated method stub
	Map<String,Set<String>> traveller=new TreeMap<String,Set<String>>();
		
		Set<String> fromset=new TreeSet<String>();
		Set<String> toset=new TreeSet<String>();
		Set<String> vehicleSet=new TreeSet<String>();
		
		String msg=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT SOURCE_ADDRESS,DESTINATION,CAB_MODEL FROM cab_route";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					fromset.add(rs.getString("SOURCE_ADDRESS"));
					toset.add(rs.getString("DESTINATION"));
					vehicleSet.add(rs.getString("CAB_MODEL"));
					
				}
				
				traveller.put("fromCity", fromset);
				traveller.put("toCity", toset);
				traveller.put("vehicleType", vehicleSet);
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return traveller;
	}

	public List<CabHomeSearch> searchHCab(String from, String to, String date, String vehicleType,String location) {
		// TODO Auto-generated method stub
		List<CabHomeSearch> cabSearch=new ArrayList<CabHomeSearch>();
		String msg=null;
		PreparedStatement pst=null;
		
		String query=null;
		
		Date date1=new Date();
		DateFormat format=new SimpleDateFormat("dd-MM-yyyy");
		String date2=format.format(date1);
		
		if(from!=null && to!=null && date==null && vehicleType==null && location!=null){
			
			query="select rt.*,ass.DRIVER_ID,ass. CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID where rt.SOURCE_ADDRESS='"+from+"' and rt.DESTINATION='"+to+"' and '"+location+"' in(FROM_LOCATION) and PICK_UP_DATE>='"+date2+"' and rt.STATUS='ACTIVE' and rt.AVAILABILITY='YES' group by rt.CAB_ROUTE_ID";
			
		}else if(from==null && to==null && date==null && vehicleType==null){
				
				query="select rt.*,ass.DRIVER_ID,ass. CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID group by rt.CAB_ROUTE_ID";
				
			}else if(!from.equals("") && !to.equals("") && date.equals("") && vehicleType.equals("")){
				
				query="select rt.*,ass.DRIVER_ID,ass.CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID where rt.SOURCE_ADDRESS='"+from+"' and rt.DESTINATION='"+to+"' and PICK_UP_DATE>='"+date2+"' and rt.STATUS='ACTIVE' and rt.AVAILABILITY='YES' group by rt.CAB_ROUTE_ID";
				
			}else if(!from.equals("") && !to.equals("") && !date.equals("") && vehicleType.equals("")){
				
				query="select rt.*,ass.DRIVER_ID,ass.CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID where rt.SOURCE_ADDRESS='"+from+"' and rt.DESTINATION='"+to+"' and rt.PICK_UP_DATE='"+date+"' and rt.STATUS='ACTIVE' and rt.AVAILABILITY='YES' group by rt.CAB_ROUTE_ID";
				
			}else if(!from.equals("") && !to.equals("") && !date.equals("") && !vehicleType.equals("")){
				
				query="select rt.*,ass.DRIVER_ID,ass.CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID where rt.SOURCE_ADDRESS='"+from+"' and rt.DESTINATION='"+to+"' and rt.PICK_UP_DATE='"+date+"' and rt.CAB_BRAND='"+vehicleType+"' and rt.STATUS='ACTIVE' and rt.AVAILABILITY='YES' group by rt.CAB_ROUTE_ID";
				
			}else if(!from.equals("") && !to.equals("") && date.equals("") && !vehicleType.equals("")){
				
				query="select rt.*,ass.DRIVER_ID,ass.CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID where rt.SOURCE_ADDRESS='"+from+"' and rt.DESTINATION='"+to+"' and rt.CAB_BRAND='"+vehicleType+"' and PICK_UP_DATE>='"+date2+"' and rt.STATUS='ACTIVE' and rt.AVAILABILITY='YES' group by rt.CAB_ROUTE_ID";
				
			}else{
				
				query="select rt.*,ass.DRIVER_ID,ass.CAB_ID from cab_route rt left join assign_driver_cab ass on rt.CAB_ID=ass.CAB_ID group by rt.CAB_ROUTE_ID where rt.STATUS='ACTIVE' and PICK_UP_DATE>='"+date2+"' and rt.AVAILABILITY='YES'";
				
			}
			

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					CabHomeSearch routeBean=new CabHomeSearch();
					
					routeBean.setCAB_ROUTE_ID(rs.getInt("CAB_ROUTE_ID"));
					routeBean.setCAB_MODEL(rs.getString("CAB_MODEL"));
					routeBean.setSOURCE_ADDRESS(rs.getString("SOURCE_ADDRESS"));
					routeBean.setDESTINATION(rs.getString("DESTINATION"));
					routeBean.setPICK_UP_DATE(rs.getString("PICK_UP_DATE"));
					routeBean.setFROM_LOCATION(rs.getString("FROM_LOCATION"));
					routeBean.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					routeBean.setPRICE(rs.getString("PRICE"));
					routeBean.setCAB_ID(rs.getString("CAB_ID"));
					routeBean.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					routeBean.setSTATUS(rs.getString("STATUS"));
					routeBean.setAVAILABILITY(rs.getString("AVAILABILITY"));
					routeBean.setDRIVER_ID(rs.getString("DRIVER_ID"));
					routeBean.setROUTE_GEN_ID(rs.getString("ROUTE_GEN_ID"));
					
					cabSearch.add(routeBean);
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabSearch;
	}

	public DriverBean getDriverNames(String driverId,String cabId) {
		// TODO Auto-generated method stub
		DriverBean driver=new DriverBean();
		PreparedStatement pst=null;
		
			try {
				String query="SELECT ass.DRIVER_ID,ass.CAB_ID,ad.* from assign_driver_cab ass inner join add_driver ad on ass.DRIVER_ID=ad.DRIVER_ID where ass.STATUS='ACTIVE' and ass.DRIVER_ID='"+driverId+"' and ass.CAB_ID='"+cabId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					driver.setFIRST_NAME(rs.getString("FIRST_NAME"));
					driver.setLAST_NAME(rs.getString("LAST_NAME"));
					driver.setDRIVING_EXP(rs.getString("DRIVING_EXP"));
					driver.setDRIVER_AVAILABILITY(rs.getString("AVAILABILITY"));
					driver.setDRIVER_ID(rs.getString("DRIVER_ID"));
					driver.setLICENSE_NO(rs.getString("LICENSE_NO"));
					driver.setREGISTERED_STATE(rs.getString("REGISTERED_STATE"));
					driver.setSTATUS(rs.getString("STATUS"));
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return driver;
	}

	public String getcabId(String cabRegNo) {
		// TODO Auto-generated method stub
		String cabId=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT CAB_GEN_ID FROM add_cab where CAB_REG_NO='"+cabRegNo+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cabId=rs.getString("CAB_GEN_ID");
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabId;
	}

	public AddCab getCabDetails(String cabRegNo) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		
		AddCab addCab=new AddCab();
		Blob blob;
		byte[] image;
			try {
				String query="SELECT * FROM add_cab where CAB_REG_NO='"+cabRegNo+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					addCab.setCAB_GEN_ID(rs.getString("CAB_GEN_ID"));
					addCab.setCAB_REG_NO(rs.getString("CAB_REG_NO"));
					addCab.setCAB_BRAND(rs.getString("CAB_BRAND"));
					addCab.setCAB_MODEL(rs.getString("CAB_MODEL"));
					addCab.setADDRESS(rs.getString("ADDRESS"));
					addCab.setBODY_TYPE(rs.getString("BODY_TYPE"));
					addCab.setCAB_SEQ_ID(rs.getInt("CAB_SEQ_ID"));
					addCab.setCERTIFIED_COMP_NAME(rs.getString("CERTIFIED_COMP_NAME"));
					addCab.setCITY(rs.getString("CITY"));
					addCab.setCOLOR(rs.getString("COLOR"));
					addCab.setCURRENT_MILEAGE(rs.getString("CURRENT_MILEAGE"));
					addCab.setDISTRICT(rs.getString("DISTRICT"));
					addCab.setFUEL_TYPE(rs.getString("FUEL_TYPE"));
					addCab.setINSURENCE_COMP_NAME(rs.getString("INSURENCE_COMP_NAME"));
					addCab.setKM_DRIVEN(rs.getString("KM_DRIVEN"));
					addCab.setMOBILE_NO(rs.getString("MOBILE_NO"));
					addCab.setMODEL_YEAR(rs.getString("MODEL_YEAR"));
					addCab.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					addCab.setPINCODE(rs.getString("PINCODE"));
					addCab.setREGISTERED_CITY(rs.getString("REGISTERED_CITY"));
					addCab.setREGISTERED_STATE(rs.getString("REGISTERED_STATE"));
					addCab.setREGISTERED_YEAR(rs.getString("REGISTERED_YEAR"));
					addCab.setSTATE(rs.getString("STATE"));
					addCab.setSTATUS(rs.getString("STATUS"));
					addCab.setTRANSMISSION(rs.getString("TRANSMISSION"));
					
					blob=rs.getBlob("CAB_PHOTO");
					image=blob.getBytes(1, (int)blob.length());
					String photo=Base64.encode(image);
					
					addCab.setCAB_PHOTO(photo);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return addCab;
	}

	public String insertCabBooking(CabBook cabBook,String cabOwner) {
		// TODO Auto-generated method stub
		String bookingId=null;
		PreparedStatement pst=null;
//		PreparedStatement pst1=null;
		
		try{
			String bookId=new IdGen().getId("CAB_BOOKING_ID");
			String cabBookId=new BookingId().cabBookingId(bookId);
			Date date=new Date();
			DateFormat format=new SimpleDateFormat("dd-MM-yyyy");
			String date1=format.format(date);
			
			String query="insert into cab_booking values(?,?,?,?,?,?,?,?,?,?,?)";
//			String query1="update cab_route set RIDING_TYPE='BOOKED',STATUS='INACTIVE' where CAB_ID='"+cabBook.getCAB_ID()+"' and PICK_UP_DATE='"+date1+"' and STATUS='ACTIVE'";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
//			pst1=con.prepareStatement(query1);
			
			pst.setInt(1, 0);
			pst.setString(2, cabBook.getUSER_EMAIL());
			pst.setString(3, cabBook.getCONTACT_NO());
			pst.setString(4, cabBook.getPICK_UP_ADDRESS());
			pst.setString(5, cabBookId);
			pst.setString(6, date1);
			pst.setString(7, "BOOKED");
			pst.setString(8, cabBook.getCAB_ID());
			pst.setString(9, cabOwner);
			pst.setString(10, cabBook.getDROPPING_ADDRESS());
			pst.setString(11, cabBook.getCAB_ROUTE_ID());
			int i=pst.executeUpdate();
//			int j=pst1.executeUpdate();
			
			if(i>0){
				
				bookingId=cabBookId;
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}finally {
			
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
		}
		
		return bookingId;
	}

	public List<CabBook> getCabBookedDetails(String email) {
		// TODO Auto-generated method stub
		List<CabBook> bookList=new ArrayList<CabBook>();
		PreparedStatement pst=null;

			try {
				String query="SELECT * FROM cab_booking where '"+email+"' in (USER_EMAIL || CAB_OWNER_ID)";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					CabBook cab=new CabBook();
					
					cab.setBOOKING_ID(rs.getString("BOOKING_ID"));
					cab.setCONTACT_NO(rs.getString("CONTACT_NO"));
					cab.setPICK_UP_ADDRESS(rs.getString("PICK_UP_ADDRESS"));
					cab.setBOOKING_STATUS(rs.getString("BOOKING_STATUS"));
					cab.setBOOKING_DATE(rs.getString("BOOKING_DATE"));
					cab.setCAB_ID(rs.getString("CAB_ID"));
					bookList.add(cab);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return bookList;
	}

	public CabBook cabBookingDetails(String bookingId) {
		// TODO Auto-generated method stub
		CabBook cab=new CabBook();
		PreparedStatement pst=null;

			try {
				String query="SELECT * FROM cab_booking where BOOKING_ID='"+bookingId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					cab.setBOOKING_ID(rs.getString("BOOKING_ID"));
					cab.setCONTACT_NO(rs.getString("CONTACT_NO"));
					cab.setPICK_UP_ADDRESS(rs.getString("PICK_UP_ADDRESS"));
					cab.setBOOKING_STATUS(rs.getString("BOOKING_STATUS"));
					cab.setBOOKING_DATE(rs.getString("BOOKING_DATE"));
					cab.setCAB_ID(rs.getString("CAB_ID"));
					cab.setUSER_EMAIL(rs.getString("USER_EMAIL"));
					cab.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					cab.setCAB_ROUTE_ID(rs.getString("CAB_ROUTE_ID"));
					cab.setDROPPING_ADDRESS(rs.getString("DROPPING_ADDRESS"));
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cab;
	}

	public String getCabRouteStatus(String cabId) {
		// TODO Auto-generated method stub
		String status=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT STATUS FROM cab_route where CAB_ID='"+cabId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					status=rs.getString("STATUS");
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return status;
	}

	public List<CabRoute> getCabRouteDetails(String query) {
		// TODO Auto-generated method stub
		List<CabRoute> routeList=new ArrayList<CabRoute>();
		PreparedStatement pst=null;

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				byte photo[];
				Blob blob;
				while(rs.next()){
					
					CabRoute route=new CabRoute();
					
					route.setCAB_ROUTE_ID(rs.getInt("CAB_ROUTE_ID"));
					route.setCAB_MODEL(rs.getString("CAB_MODEL"));
					route.setSOURCE_ADDRESS(rs.getString("SOURCE_ADDRESS"));
					route.setDESTINATION(rs.getString("DESTINATION"));
					route.setPICK_UP_DATE(rs.getString("PICK_UP_DATE"));
					route.setFROM_LOCATION(rs.getString("FROM_LOCATION"));
					route.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					route.setPRICE(rs.getString("PRICE"));
					route.setPRICE_PER_KM(rs.getString("PRICE_PER_KM"));
					route.setCAB_ID(rs.getString("CAB_ID"));
					route.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					route.setAVAILABILITY(rs.getString("AVAILABILITY"));
					route.setSTATUS(rs.getString("STATUS"));
					route.setROUTE_GEN_ID(rs.getString("ROUTE_GEN_ID"));
					route.setROUTE_ADDED_TIME(rs.getString("ROUTE_ADDED_TIME"));
				
					routeList.add(route);
				
					
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return routeList;
	}

	public List<CabRoute> searchCabRoute(String cabId, String from, String to,String email) {
		// TODO Auto-generated method stub
		 String query="";
		 
		 if(cabId.equals("All")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"'";
			 
		 }else if((!cabId.equals("")||!cabId.equals("All")) && !from.equals("") && !to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and SOURCE_ADDRESS='"+from+"' and DESTINATION='"+to+"'";
			 
		 }else if(cabId.equals("") && !from.equals("") && !to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and SOURCE_ADDRESS='"+from+"' and DESTINATION='"+to+"'";
			 
		 }else if(!cabId.equals("") && !from.equals("") && to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and SOURCE_ADDRESS='"+from+"'";
			 
		 }else if(!cabId.equals("") && from.equals("") && !to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and CAB_ID='"+cabId+"' and DESTINATION='"+to+"'";
			 
		 }else if((!cabId.equals("")||!cabId.equals("All")) || !from.equals("") || !to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and ('"+cabId+"' in (CAB_ID)) || ('"+from+"' in (SOURCE_ADDRESS)) || ('"+to+"' in (DESTINATION))";
			 
		 }else if((cabId.equals("")||cabId.equals("All")) || !from.equals("") || !to.equals("")){
			 
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"' and ('"+from+"' in (SOURCE_ADDRESS)) || ('"+to+"' in (DESTINATION))";
			 
		 }else{
			 query="select * from cab_route where CAB_OWNER_ID='"+email+"'";
		 }
		 
		 List<CabRoute> routeList=getCabRouteDetails(query);
		
		return routeList;
	}

	public String changeRouteStatus(String routeSeqId, String status) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			
			String query="update cab_route set STATUS='"+status+"' where CAB_ROUTE_ID='"+routeSeqId+"'";
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);

		    int i=pst.executeUpdate();
		    if(i>0){
		    	if(status.equals("INACTIVE")){
				message="Route Inactivated SuccessFully......";
		    	}else{
		    		message="Route Activated SuccessFully..";
		    	}
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public String changeCabAvailability(String cabSeqId, String avl) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			
			String query="update cab_route set AVAILABILITY='"+avl+"' where CAB_ROUTE_ID='"+cabSeqId+"'";
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);

		    int i=pst.executeUpdate();
		    if(i>0){
		    	if(avl.equals("NO")){
				message="Your Cab Is Not Available Now......";
		    	}else{
		    		message="Your Cab Is Available Now..";
		    	}
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public List<CabBook> getBookingDetails(String query) {
		// TODO Auto-generated method stub
		List<CabBook> bookList=new ArrayList<CabBook>();
		PreparedStatement pst=null;

			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()){
					CabBook book=new CabBook();
					book.setCAB_BOOKING_SEQ_NO(rs.getInt("CAB_BOOKING_SEQ_NO"));
					book.setUSER_EMAIL(rs.getString("USER_EMAIL"));
					book.setCONTACT_NO(rs.getString("CONTACT_NO"));
					book.setPICK_UP_ADDRESS(rs.getString("PICK_UP_ADDRESS"));
					book.setBOOKING_ID(rs.getString("BOOKING_ID"));
					book.setBOOKING_DATE(rs.getString("BOOKING_DATE"));
					book.setBOOKING_STATUS(rs.getString("BOOKING_STATUS"));
					book.setCAB_ID(rs.getString("CAB_ID"));
					book.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					book.setDROPPING_ADDRESS(rs.getString("DROPPING_ADDRESS"));
					book.setCAB_ROUTE_ID(rs.getString("CAB_ROUTE_ID"));
					bookList.add(book);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return bookList;
	}

	public List<CabBook> searchCabBooking(String cabId, String status, String email) {
		// TODO Auto-generated method stub
		
		String query="";
		if(cabId.equals("All") && status.equals("")){
			query="select * from cab_booking where CAB_OWNER_ID='"+email+"'";	
		}else if(cabId.equals("All") && !status.equals("")){
			query="select * from cab_booking where BOOKING_STATUS='"+status+"' and CAB_OWNER_ID='"+email+"'";
		}else if(!cabId.equals("") && !status.equals("")){
			query="select * from cab_booking where CAB_ID='"+cabId+"' and BOOKING_STATUS='"+status+"' and CAB_OWNER_ID='"+email+"'";
		}else if(!cabId.equals("")){
			query="select * from cab_booking where CAB_ID='"+cabId+"' and CAB_OWNER_ID='"+email+"'";
		}else if(!status.equals("")){
			query="select * from cab_booking where BOOKING_STATUS='"+status+"' and CAB_OWNER_ID='"+email+"'";
		}else{
			query="select * from cab_booking where CAB_OWNER_ID='"+email+"'";
		}
		List<CabBook> bookList=getBookingDetails(query);
		
		return bookList;
	}

	public String changeBookingStatus(String cabId, String bookingId, String email,String status,String userEmail,String date) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			String query="update cab_route set STATUS='ACTIVE' where CAB_ID='"+cabId+"' and CAB_OWNER_ID='"+email+"' and PICK_UP_DATE='"+date+"' and STATUS='INACTIVE'";
			String query1="update cab_booking set BOOKING_STATUS='"+status+"' where BOOKING_ID='"+bookingId+"'";
			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);
		    pst1=con.prepareStatement(query1);
		    
		    int i=pst.executeUpdate();
		    int j=pst1.executeUpdate();
		    if(i>0 && j>0){
		    	if(status.equals("CANCELED")){
				message="Booking Canceled Successfully...";
		    	}else{
		    		message="Booking Rejected successfully..";
		    	}
			}
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public String confirmBookingStatus(String cabId, String bookingId, String email, String status,String date) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			String query="update cab_booking set BOOKING_STATUS='"+status+"' where BOOKING_ID='"+bookingId+"'";
			String query1="update cab_route set STATUS='INACTIVE' where CAB_ID='"+cabId+"' and PICK_UP_DATE='"+date+"' and STATUS='ACTIVE'";

			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);
		    pst1=con.prepareStatement(query1);

		    int i=pst.executeUpdate();
		    int j=pst1.executeUpdate();
		   
		    if(i>0 && j>0){
		    	if(status!=null && status.equals("CONFIRMED")){
				message="Booking Confirmed Successfully...";
		    	}else{
		    		message="Booking Completed Successfully...";
		    	}
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public String cancelCabBooking(String bookingId, String reason, String userType) {
		// TODO Auto-generated method stub
		String msg=null;
		PreparedStatement pst=null;
		
		try{
			
			String query="insert into cab_booking_cancellation values(?,?,?,?,?)";
			
			con=DBConnection.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1, 0);
			pst.setString(2, bookingId);
			pst.setString(3, reason);
			pst.setString(4, userType);
			pst.setString(5, "CANCELED");
			
			int i=pst.executeUpdate();
			
			if(i>0){
				
				msg="Cab Route Added Successfully..";
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}finally {
			
			try{
				pst.close();
				con.close();
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
		}
		
		return msg;
	}

	public CabRoute cabRouteByRouteId(String routeId) {
		// TODO Auto-generated method stub
		
		String query="select * from cab_route where ROUTE_GEN_ID='"+routeId+"'";
		
		List<CabRoute> routeList=getCabRouteDetails(query);
		
		CabRoute route=null;
		for(int i=0;i<routeList.size();i++){
			route=routeList.get(i);
		}
		
		return route;
	}

	public String updateBookingStatus(String bookingId,String status) {
		// TODO Auto-generated method stub
		PreparedStatement pst=null;
		String message=null;
//		String date1=date.getSQLDate(driver.getDOB());
		try{ 
			String query="update cab_booking set BOOKING_STATUS='"+status+"' where BOOKING_ID='"+bookingId+"'";

			con=DBConnection.getConnection();
		    pst=con.prepareStatement(query);

		    int i=pst.executeUpdate();
		   
		    if(i>0){
		    	
				message="Booking Completed Successfully,Please Update Your Route Here!.";
		    	
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}	
		finally {
	           try {
	        	   pst.close();
				   con.close();
			} catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        } 
		
		return message;
	}

	public Set<String> getCabBookingStatus(String routeId) {
		// TODO Auto-generated method stub
		Set<String> status=new TreeSet<String>();
		PreparedStatement pst=null;

			try {
				String query="SELECT BOOKING_STATUS FROM cab_booking where CAB_ROUTE_ID='"+routeId+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					status.add(rs.getString("BOOKING_STATUS"));
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return status;
	}

	public List<AddCab> getCabFullDetails(String query) {
		// TODO Auto-generated method stub
	PreparedStatement pst=null;
		
		List<AddCab> cabList=new ArrayList<AddCab>();
		Blob blob;
		byte[] image;
			try {
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query,pst.RETURN_GENERATED_KEYS);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					AddCab addCab=new AddCab();
					
					addCab.setCAB_GEN_ID(rs.getString("CAB_GEN_ID"));
					addCab.setCAB_REG_NO(rs.getString("CAB_REG_NO"));
					addCab.setCAB_BRAND(rs.getString("CAB_BRAND"));
					addCab.setCAB_MODEL(rs.getString("CAB_MODEL"));
					addCab.setADDRESS(rs.getString("ADDRESS"));
					addCab.setBODY_TYPE(rs.getString("BODY_TYPE"));
					addCab.setCAB_SEQ_ID(rs.getInt("CAB_SEQ_ID"));
					addCab.setCERTIFIED_COMP_NAME(rs.getString("CERTIFIED_COMP_NAME"));
					addCab.setCITY(rs.getString("CITY"));
					addCab.setCOLOR(rs.getString("COLOR"));
					addCab.setCURRENT_MILEAGE(rs.getString("CURRENT_MILEAGE"));
					addCab.setDISTRICT(rs.getString("DISTRICT"));
					addCab.setFUEL_TYPE(rs.getString("FUEL_TYPE"));
					addCab.setINSURENCE_COMP_NAME(rs.getString("INSURENCE_COMP_NAME"));
					addCab.setKM_DRIVEN(rs.getString("KM_DRIVEN"));
					addCab.setMOBILE_NO(rs.getString("MOBILE_NO"));
					addCab.setMODEL_YEAR(rs.getString("MODEL_YEAR"));
					addCab.setNO_OF_PASSENGER(rs.getString("NO_OF_PASSENGER"));
					addCab.setPINCODE(rs.getString("PINCODE"));
					addCab.setREGISTERED_CITY(rs.getString("REGISTERED_CITY"));
					addCab.setREGISTERED_STATE(rs.getString("REGISTERED_STATE"));
					addCab.setREGISTERED_YEAR(rs.getString("REGISTERED_YEAR"));
					addCab.setSTATE(rs.getString("STATE"));
					addCab.setSTATUS(rs.getString("STATUS"));
					addCab.setTRANSMISSION(rs.getString("TRANSMISSION"));
					addCab.setCAB_OWNER_ID(rs.getString("CAB_OWNER_ID"));
					
					blob=rs.getBlob("CAB_PHOTO");
					image=blob.getBytes(1, (int)blob.length());
					String photo=Base64.encode(image);
					
					addCab.setCAB_PHOTO(photo);
					
					cabList.add(addCab);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return cabList;
	}

	public List<AddCab> searchCDSBCab(String email) {
		// TODO Auto-generated method stub
		
		String query=null;
		
		if(email!=null){
			
			query="select * from add_cab where CAB_OWNER_ID='"+email+"'";
		}
		List<AddCab> cabList=getCabFullDetails(query);
		
		return cabList;
	}

	public String getBusinessName(String email) {
		// TODO Auto-generated method stub
		String businessName=null;
		PreparedStatement pst=null;

			try {
				String query="SELECT BUSINESS_NAME FROM update_reg_user where USER_EMAIL='"+email+"'";
				con=DBConnection.getConnection();
			    pst=con.prepareStatement(query);
			
				ResultSet rs = pst.executeQuery();
				while(rs.next()){
					
					businessName=rs.getString("BUSINESS_NAME");
				}
				
				rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					pst.close();
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		
		return businessName;
	}

}
